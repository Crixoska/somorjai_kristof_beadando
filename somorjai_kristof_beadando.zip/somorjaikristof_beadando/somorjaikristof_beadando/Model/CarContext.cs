﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using somorjaikristof_beadando.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace somorjaikristof_beadando.Model
{
    internal class CarContext : DbContext
    {
        private string connectionString = ConfigurationManager.AppSettings.Get("DBurl");

        public CarContext()
        {
            this.connectionString = connectionString;
            
        }

        public DbSet<Car> Cars { get; set; }
        public DbSet<User> users { get; set; }
        public DbSet<berelt_jarmu> berelt_jarmuvek { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL(connectionString);
        }


    }
}

