﻿using Microsoft.EntityFrameworkCore;
using MySqlX.XDevAPI;
using somorjaikristof_beadando.Model;
using somorjaikristof_beadando.Repository;
using somorjaikristof_beadando.View;
using somorjaikristofbeadando.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace somorjaikristof_beadando.View
{
    /// <summary>
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        private List<Car> selectCars;
        private CarRepository carRepository = null;
        private Op operation = Op.No;

        enum Op
        {
            Add, //INSERT
            Upd, //UPDATE
            No //Not set
        }
        public AdminWindow()
        {
            carRepository = new CarRepository(new CarContext());
            InitializeComponent();
            LoadCarsGrid();
        }
        private void LoadCarsGrid()
        {
            Cursor = Cursors.Wait;
            selectCars = carRepository.GetCars();
            autok_grid.ItemsSource = selectCars;
            Cursor = Cursors.Arrow;
            rendszamTextBox.IsEnabled = false;
            szinTextBox.IsEnabled = false;
            evjaratTextBox.IsEnabled = false;
            tipusTextBox.IsEnabled = false;
            rendszamTextBox.Text = "";
            szinTextBox.Text = "";
            evjaratTextBox.Text = "";
            tipusTextBox.Text = "";


        }
        private void New_Btn_Click(object sender, RoutedEventArgs e)
        {
            rendszamTextBox.IsEnabled = true;
            szinTextBox.IsEnabled = true;
            evjaratTextBox.IsEnabled = true;
            tipusTextBox.IsEnabled = true;
            rendszamTextBox.Text = "";
            szinTextBox.Text = "";
            evjaratTextBox.Text = "";
            tipusTextBox.Text = "";
            operation = Op.Add;
            rendszamTextBox.Focus();
        }

        private void Save_Btn_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Add && rendszamTextBox.Text != "" && szinTextBox.Text != "" && evjaratTextBox.Text != "" && tipusTextBox.Text != "")
            {
                carRepository.InsertCar(new Car
                {
                    rendszam = rendszamTextBox.Text,
                    szin = szinTextBox.Text,
                    berelheto = 1,
                    evjarat = Int32.Parse(evjaratTextBox.Text),
                    tipus = tipusTextBox.Text

                });
                carRepository.Save();

                LoadCarsGrid();

                rendszamTextBox.IsEnabled = false;
                szinTextBox.IsEnabled = false;
                evjaratTextBox.IsEnabled = false;
                tipusTextBox.IsEnabled = false;
                rendszamTextBox.Text = "";
                szinTextBox.Text = "";
                evjaratTextBox.Text = "";
                tipusTextBox.Text = "";
                operation = Op.No;
                //set focus
                rendszamTextBox.Focus();
            }

        }
    }
}
