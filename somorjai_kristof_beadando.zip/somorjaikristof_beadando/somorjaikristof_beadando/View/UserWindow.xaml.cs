﻿using Microsoft.EntityFrameworkCore;
using MySqlX.XDevAPI;
using somorjaikristof_beadando.Model;
using somorjaikristof_beadando.Repository;
using somorjaikristof_beadando.View;
using somorjaikristofbeadando.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace somorjaikristof_beadando
{
    /// <summary>
    /// Interaction logic for UserWindow.xaml
    /// </summary>
    public partial class UserWindow : Window
    {
        private List<Car> selectCars;
        private List<berelt_jarmu> selectRentedCars;
        private BereltRepository bereltRepository;
        private CarRepository carRepository = null;
        private CarContext context;
        public UserWindow()
        {
            carRepository = new CarRepository(new CarContext());
            context = new CarContext();
            bereltRepository = new BereltRepository(context);  
            InitializeComponent();
            LoadCarsGrid();
            LoadRentedCarsGrid();
        }

        private void LoadCarsGrid()
        {
            Cursor = Cursors.Wait;
            selectCars = carRepository.GetCars();
            autok_grid.ItemsSource = selectCars;
            Cursor = Cursors.Arrow;
            

        }
        private void LoadRentedCarsGrid()
        {
            Cursor = Cursors.Wait;
            selectRentedCars = bereltRepository.GetRentedCars();
            bereltautok_grid.ItemsSource = selectRentedCars;
            Cursor = Cursors.Arrow;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            berelt_jarmu berelt = new berelt_jarmu { rendszam=rendszam_textbox.Text, berles_idopont=DateTime.Parse(datum_elso.Text) , berles_lejarat=DateTime.Parse(datum_masodik.Text), user = context.users.FirstOrDefault()};
            bereltRepository.AddJarmu(berelt);
            
        }

        private void Exit_Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Biztos ki szeretne lépni?", "Confirmation", MessageBoxButton.YesNoCancel) == MessageBoxResult.Yes)
                System.Environment.Exit(0);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            AdminWindow adminWindow = new AdminWindow();
            adminWindow.Show();
        }
    }
}
