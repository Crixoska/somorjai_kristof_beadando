﻿using somorjaikristof_beadando.Model;
using somorjaikristof_beadando.Repository;
using somorjaikristof_beadando.View;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace somorjaikristof_beadando
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<User> selectUsers;
        private UserRepository userRepository = null;
        CarContext context;
  
        public MainWindow()
        {
           
            userRepository = new UserRepository(new CarContext());
            context = new CarContext();
            InitializeComponent();
            CheckDataBaseConnection();
            context.Database.EnsureCreated();
        }
        private void CheckDataBaseConnection()
        {
            try
            {
                CarContext dbcontext = new CarContext();

                if (!dbcontext.Database.CanConnect())
                {
                    MessageBox.Show("Database connection falied.");
                    System.Environment.Exit(1);
                }
                dbcontext.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database connection failed with an exception during connection!");
                throw;
            }
        }

        private void btnLoginwin_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginview = new LoginWindow();
            loginview.Show();
            this.Close();
            
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            if (tboxRegnev.Text != "" && tboxRegjelsz.Text != "")
            {
                User ujuser = new User { username = tboxRegnev.Text, password = tboxRegjelsz.Text };
                context.users.Add(ujuser);
                context.SaveChanges();
                MessageBox.Show("Sikeres regisztráció!");
            }
            else 
            {
                MessageBox.Show("Kérlek minden mezőt tölts ki!");
            }
        }

    }
}
