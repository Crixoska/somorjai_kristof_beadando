﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using somorjaikristof_beadando;
using Microsoft.EntityFrameworkCore;
using somorjaikristof_beadando.Model;
using System.Diagnostics.Metrics;
using MySqlX.XDevAPI;

namespace somorjaikristof_beadando.Repository
{
    class UserRepository
    {
        private CarContext CarContext;
        public UserRepository(CarContext context)
        {
            this.CarContext = context;
        }
        public List<User> GetUsers()
        {
            return CarContext.users.ToList();
        }
    }
}
