﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using somorjaikristof_beadando;
using Microsoft.EntityFrameworkCore;
using somorjaikristof_beadando.Model;
using System.Diagnostics.Metrics;
using System.Dynamic;
using System.Xml.Xsl;

namespace somorjaikristofbeadando.Repository
{
    class CarRepository
    {
        private CarContext CarContext;
        public CarRepository(CarContext context)
        {
            this.CarContext = context;
        }
        public List<Car> GetCars()
        {
            return CarContext.Cars.ToList();
        }
        public List<Car> GetCarsByRendszam(string rendszam)
        {
            return CarContext.Cars.Where(p => p.rendszam == rendszam).ToList();
        }
        public void InsertCar(Car car)
        {
            CarContext.Cars.Add(car);
        }
        public void DeleteCar(int carID)
        {
        //    Car car = CarContext.Car.Find(carID);
          //  CarContext.Cars.Remove(car);
        }
        public void UpdateCar(Car car)
        {
           // CarContext.Cars.Find(country.Id).countryname = country.countryname;
         //   CountryContext.Countries.Find(country.Id).population = country.population;

        }
        public void Save()
        {
            CarContext.SaveChanges();
        }
        public void Dispose()
        {
            CarContext.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
