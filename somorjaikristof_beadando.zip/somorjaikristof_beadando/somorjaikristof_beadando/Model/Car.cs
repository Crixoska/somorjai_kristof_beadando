﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace somorjaikristof_beadando.Model
{
    [Table("autok")]
    class Car
    {
        [Key]
        [Column("rendszam")]
        public string rendszam { get; set; }
        [Column("berelheto")]
        public int berelheto { get; set; }
        [Column("szin")]
        public string szin { get; set; }
        [Column("evjarat")]
        public int evjarat { get; set; }
        [Column("tipus")]
        public string tipus { get; set; }
    }
}

