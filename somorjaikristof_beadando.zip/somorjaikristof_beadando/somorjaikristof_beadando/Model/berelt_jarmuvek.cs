﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace somorjaikristof_beadando.Model
{
    [Table("berelt_jarmuvek")]
    class berelt_jarmu
    {
        [Key]
        [Column("rendszam")]
        public string rendszam { get; set; }
        [Column("berles_lejarat")]
        public DateTime berles_lejarat { get; set; }
        [Column("berles_idopont")]
        public DateTime berles_idopont { get; set; }
        public User user { get; set; }
    }
}

