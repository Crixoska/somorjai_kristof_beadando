﻿using somorjaikristof_beadando.Model;
using somorjaikristof_beadando.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace somorjaikristof_beadando.Repository
{
    class BereltRepository
    {
        private CarContext CarContext;
        public BereltRepository(CarContext context)
        {
            CarContext = context;
        }
        public List<berelt_jarmu> GetRentedCars()
        {
            return CarContext.berelt_jarmuvek.ToList();
        }
        public bool AddJarmu(berelt_jarmu jarmu)
        {
            try
            {
                CarContext.berelt_jarmuvek.Add(jarmu);
                CarContext.SaveChanges();
                MessageBox.Show("Sikeres Bérlés!");
            }
            catch 
            {
                MessageBox.Show("Jármű már ki van bérelve.");
            }
            return true;
        }

    }
}
