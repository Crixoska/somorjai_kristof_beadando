﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using somorjaikristofbeadando.Repository;
using somorjaikristof_beadando.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace CarRepositoryTests
{
    [TestClass]
    public class CarRepositoryTests
    {
        private Mock<CarContext> mockContext;
        private CarRepository carRepository;

        [TestInitialize]

        [TestMethod]
        public void GetCars_ReturnsAllCars()
        {
            // Act
            var result = carRepository.GetCars();

            // Assert
            Assert.AreEqual(2, result.Count);
            Assert.AreEqual("ABC123", result[0].rendszam);
            Assert.AreEqual("XYZ789", result[1].rendszam);
        }

        [TestMethod]
        public void GetCarsByRendszam_ReturnsCorrectCar()
        {
            // Act
            var result = carRepository.GetCarsByRendszam("ABC123");

            // Assert
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual("ABC123", result[0].rendszam);
        }

        [TestMethod]
        public void InsertCar_AddsCar()
        {
            // Arrange
            var newCar = new Car { rendszam = "DEF456", szin = "Green", evjarat = 2021, tipus = "Hatchback" };

            // Act
            carRepository.InsertCar(newCar);

            // Assert
            mockContext.Verify(c => c.Cars.Add(It.IsAny<Car>()), Times.Once);
        }

        [TestMethod]
        public void DeleteCar_RemovesCar()
        {
            // Arrange
            var car = new Car { rendszam = "ABC123", szin = "Red", evjarat = 2020, tipus = "Sedan" };
            mockContext.Setup(c => c.Cars.Find(It.IsAny<string>())).Returns(car);

            // Act
            carRepository.DeleteCar("ABC123");

            // Assert
            mockContext.Verify(c => c.Cars.Remove(It.IsAny<Car>()), Times.Once);
        }

        [TestMethod]
        public void Save_SavesChanges()
        {
            // Act
            carRepository.Save();

            // Assert
            mockContext.Verify(c => c.SaveChanges(), Times.Once);
        }
    }
}
