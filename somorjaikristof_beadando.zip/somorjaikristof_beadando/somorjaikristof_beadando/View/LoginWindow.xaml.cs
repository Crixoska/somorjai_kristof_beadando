﻿using somorjaikristof_beadando.Model;
using somorjaikristof_beadando.Repository;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace somorjaikristof_beadando.View
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private List<User> selectUsers;
        private UserRepository userRepository;
        private CarContext context;
        public string jelenlegiUser;
        public LoginWindow()
        {
            InitializeComponent();
            context = new CarContext();
            userRepository = new UserRepository(context);
        }

        private void login_button_Click(object sender, RoutedEventArgs e)
        {
            login();
        }

        private void exit_button_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Biztos ki szeretne lépni?", "Confirmation", MessageBoxButton.YesNoCancel) == MessageBoxResult.Yes)
                System.Environment.Exit(0);
        }
        private void login()
        {
            selectUsers = userRepository.GetUsers();
            foreach (var item in selectUsers)
            {
                if (item.password == passwordBox.Password && item.username == username_textBox.Text)
                {
                    jelenlegiUser = item.username;
                    MessageBox.Show("Sikeres bejelentkezés!");
                    this.Hide();
                    UserWindow userwindow = new UserWindow();
                    userwindow.Show();
                    break;
                }
                else
                {
                    MessageBox.Show("Sikertelen!");
                }
                break;
            }
        }
    }
}
